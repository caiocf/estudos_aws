# Kinesis Data Streams (PROVISIONED) com Terraform (2 shards)

Este projeto cria um **Amazon Kinesis Data Stream** em **modo provisionado (PROVISIONED)** usando Terraform, com **2 shards** por padrão.
No momento o Kinesis não faz parte dos serviço do AWS Free Tier, conforme a documentação https://aws.amazon.com/pt/free/?ams%23interactive-card-vertical%23pattern-data--662440127.filter=%257B%2522search%2522%253A%2522data%2520stream%2522%257D


## Arquitetura

Producer (AWS CLI / app) → **Kinesis Data Stream (2 shards)** → Consumer (AWS CLI / app)

## Pré-requisitos

- Terraform >= 1.5
- Git Bash (caso seja no Windows)
- AWS CLI v2 configurado (`aws configure`) **ou** variáveis de ambiente (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, etc.)
- Permissões IAM para:
  - `kinesis:CreateStream`, `kinesis:DescribeStreamSummary`, `kinesis:ListShards`
  - `kinesis:PutRecord`, `kinesis:PutRecords`
  - `kinesis:GetShardIterator`, `kinesis:GetRecords`


## Como provisionar


1) Copie o arquivo de variáveis e ajuste:
```bash
cp terraform.tfvars.example terraform.tfvars
```

2) Inicialize e aplique:
```bash
terraform init
terraform apply
```

3) Confira o stream criado:
```bash
terraform output
```

## Como publicar eventos (producer)

> O parâmetro `--data` do `aws kinesis put-record` deve ser **base64** quando usamos `--cli-binary-format raw-in-base64-out`.

### Enviar 1 registro

```bash
STREAM_NAME="$(terraform output -raw stream_name)"
REGION="us-east-1"  # ajuste para sua região (ou use var.aws_region)

aws kinesis put-record   --stream-name "$STREAM_NAME"   --partition-key "pk-1"   --data "$(echo -n 'Data Entry 1' | base64)"   --region "$REGION"   --cli-binary-format raw-in-base64-out
```

### Enviar vários registros (PutRecords)

Crie um arquivo `records.json`:

```json
{
  "StreamName": "REPLACE_ME",
  "Records": [
    { "Data": "RGF0YSBFbnRyeSAy", "PartitionKey": "pk-2" },
    { "Data": "RGF0YSBFbnRyeSAz", "PartitionKey": "pk-3" }
  ]
}
```

> Observação: os valores em `Data` acima já estão em base64.  
> Exemplos:
> - `echo -n 'Data Entry 2' | base64`
> - `echo -n 'Data Entry 3' | base64`

Depois execute:

```bash
STREAM_NAME="$(terraform output -raw stream_name)"
REGION="us-east-1"

# substitui o StreamName no JSON (Linux/macOS)
sed -i.bak "s/REPLACE_ME/$STREAM_NAME/g" records.json

aws kinesis put-records   --region "$REGION"   --cli-binary-format raw-in-base64-out   --cli-input-json file://records.json
```

## Como ler eventos (consumer)

O fluxo para leitura com AWS CLI é:

1) **Listar shards**
2) Obter um **ShardIterator** (LATEST ou TRIM_HORIZON)
3) Chamar **GetRecords** em loop usando o `NextShardIterator`

### 1) Listar shards

```bash
STREAM_NAME="$(terraform output -raw stream_name)"
REGION="us-east-1"

aws kinesis list-shards   --stream-name "$STREAM_NAME"   --region "$REGION"
```

Pegue um `ShardId` do output (ex.: `shardId-000000000000`).

### 2) Obter o ShardIterator (LATEST)

```bash
SHARD_ID="shardId-000000000000"

aws kinesis get-shard-iterator   --stream-name "$STREAM_NAME"   --shard-id "$SHARD_ID"   --shard-iterator-type LATEST   --region "$REGION"
```

Copie o valor de `ShardIterator`.

> Dica: use `TRIM_HORIZON` para ler desde o início da retenção.

### 3) Ler registros

```bash
SHARD_ITERATOR="REPLACE_ME"

aws kinesis get-records   --shard-iterator "$SHARD_ITERATOR"   --limit 25   --region "$REGION"
```

O campo `Records[].Data` vem em **base64**. Para decodificar rapidamente (exemplo com `jq`):

```bash
aws kinesis get-records   --shard-iterator "$SHARD_ITERATOR"   --limit 25   --region "$REGION" | jq -r '.Records[].Data' | while read -r b64; do echo "$b64" | base64 --decode; echo; done
```

Para continuar lendo, use o `NextShardIterator` retornado.

## Limpeza (destroy)

```bash
terraform destroy
```

## Observações importantes (prova / boas práticas)

- Em **PROVISIONED**, você define `shard_count` e paga pela capacidade provisionada.
- A chave de partição (`PartitionKey`) define como os registros são distribuídos entre shards.
- Se você quer auto-scaling por throughput, considere **on-demand** (não é o objetivo deste projeto).
